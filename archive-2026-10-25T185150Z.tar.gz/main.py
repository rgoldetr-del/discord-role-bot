# main.py

import os
import logging
import importlib

from modules import auto_roles

import discord
from discord.ext import commands
from dotenv import load_dotenv

from database import db

load_dotenv()

from modules import case_shop_fix



TOKEN = os.getenv("DISCORD_TOKEN")
DEV_GUILD_ID = os.getenv("DEV_GUILD_ID", "").strip()

if not TOKEN:
    raise SystemExit("Укажи DISCORD_TOKEN в .env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
log = logging.getLogger("main")

intents = discord.Intents.default()
intents.members = True

# СНАЧАЛА создаём бота.
bot = commands.Bot(command_prefix="!", intents=intents)

# Если у тебя есть старые файлы-патчи базы, они подключатся автоматически.
# Если файлов нет, ошибки не будет.
for extra_module in ("database_addons", "database_addons_extra"):
    try:
        importlib.import_module(extra_module)
        log.info("Дополнение %s загружено", extra_module)
    except ModuleNotFoundError:
        pass
    except Exception:
        log.exception("Ошибка загрузки дополнения %s", extra_module)

# Список модулей бота.
# Если какого-то файла нет, бот напишет предупреждение и продолжит запуск.
MODULES = [
    "inventory",
    "cases",
    "case_admin",
    "wheel",
    "wheel_info",
    "market",
    "auctions",
    "gifts",
    "upgrades",
    "minigames",
    "update_v2",
    "interface_update",
    "auto_roles",
    "case_shop_fix,"
]

for module_name in MODULES:
    try:
        module = importlib.import_module(f"modules.{module_name}")
    except ModuleNotFoundError:
        log.warning("Модуль modules/%s.py не найден. Пропускаю.", module_name)
        continue
    except Exception:
        log.exception("Ошибка импорта модуля modules/%s.py", module_name)
        continue

    try:
        if hasattr(module, "register"):
            module.register(bot)
            log.info("Модуль %s зарегистрирован", module_name)
        else:
            log.warning("В модуле modules/%s.py нет функции register().", module_name)
    except Exception:
        log.exception("Ошибка регистрации модуля modules/%s.py", module_name)


async def setup_hook():
    try:
        if not hasattr(db, "db"):
            db.db = None

        await db.connect()
        log.info("База данных подключена")
    except Exception:
        log.exception("Ошибка подключения к базе данных")
        raise

    if hasattr(db, "ensure_inventory_modern"):
        try:
            await db.ensure_inventory_modern()
            log.info("Миграции инвентаря проверены")
        except Exception:
            log.exception("Ошибка миграции инвентаря")

    try:
        if DEV_GUILD_ID:
            guild = discord.Object(id=int(DEV_GUILD_ID))
            bot.tree.copy_global_to(guild=guild)
            await bot.tree.sync(guild=guild)
            log.info("Команды синхронизированы для DEV-сервера")
        else:
            await bot.tree.sync()
            log.info("Команды синхронизированы глобально")
    except ValueError:
        log.warning("DEV_GUILD_ID указан неправильно, пробую глобальную синхронизацию")
        await bot.tree.sync()
    except Exception:
        log.exception("Не удалось синхронизировать команды")


bot.setup_hook = setup_hook


@bot.event
async def on_ready():
    log.info("Бот запущен как %s", bot.user)


if __name__ == "__main__":
    bot.run(TOKEN)